/**
 * GetMention — YouTube Content Script
 *
 * Injected into youtube.com pages.
 * Posts comments and likes videos using the user's real session.
 */

(() => {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type !== 'EXECUTE_TASK' || msg.platform !== 'youtube') return;
    handleTask(msg).then(sendResponse).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  });

  async function handleTask({ action, text }) {
    switch (action) {
      case 'comment': return postComment(text);
      case 'like': return likeVideo();
      default: return { success: false, error: `Unknown action: ${action}` };
    }
  }

  async function postComment(text) {
    // Scroll to comment section
    await sleep(3000);
    window.scrollTo({ top: 500, behavior: 'smooth' });
    await sleep(2000);
    window.scrollTo({ top: 900, behavior: 'smooth' });
    await sleep(2000);

    // Click comment placeholder
    const placeholder = document.querySelector('#placeholder-area')
      || document.querySelector('#simplebox-placeholder');
    if (!placeholder) {
      return { success: false, error: 'Comment box not found — comments may be disabled' };
    }

    placeholder.click();
    await sleep(1500);

    // Find editor
    const editor = document.querySelector('#contenteditable-root');
    if (!editor) {
      return { success: false, error: 'Comment editor not found' };
    }

    editor.click();
    await sleep(800);

    // Type comment
    await humanType(editor, text);
    await sleep(1500 + Math.random() * 2000);

    // Click submit
    const submitBtn = document.querySelector('#submit-button button')
      || document.querySelector('yt-button-shape#submit-button button');
    if (submitBtn) {
      submitBtn.click();
    } else {
      // Fallback: Ctrl+Enter
      editor.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', ctrlKey: true, bubbles: true }));
    }

    await sleep(5000);

    // Verify comment appeared
    const pageText = document.body.innerText || '';
    const posted = pageText.includes(text.slice(0, 20));
    return { success: posted, verified: posted };
  }

  async function likeVideo() {
    await sleep(2000);

    const likeBtn = document.querySelector('button[aria-label*="like this video" i]:not([aria-label*="dislike"])');
    if (!likeBtn) {
      return { success: false, error: 'Like button not found' };
    }

    const pressed = likeBtn.getAttribute('aria-pressed');
    if (pressed === 'true') return { success: true, alreadyLiked: true };

    likeBtn.click();
    await sleep(2000);

    const afterPressed = likeBtn.getAttribute('aria-pressed');
    return { success: afterPressed === 'true', verified: afterPressed === 'true' };
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function humanType(element, text) {
    element.focus();
    for (const char of text) {
      document.execCommand('insertText', false, char);
      await sleep(50 + Math.random() * 80);
      if ('.!?,;'.includes(char)) await sleep(200 + Math.random() * 300);
    }
  }
})();
