/**
 * GetMention — Twitter/X Content Script
 *
 * Injected into x.com/twitter.com pages.
 * Receives tasks from background script and executes them
 * using the user's real logged-in session.
 */

(() => {
  // Listen for tasks from background
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type !== 'EXECUTE_TASK' || msg.platform !== 'twitter') return;

    handleTask(msg).then(sendResponse).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true; // async response
  });

  async function handleTask({ action, text }) {
    switch (action) {
      case 'comment': return postReply(text);
      case 'like': return likePost();
      default: return { success: false, error: `Unknown action: ${action}` };
    }
  }

  // ── Post a reply ─────────────────────────────────────────────────────────

  async function postReply(text) {
    // Wait for page to fully render
    await sleep(3000);

    // Find the reply box
    const replyBox = document.querySelector('[data-testid="tweetTextarea_0"]');
    if (!replyBox) {
      return { success: false, error: 'Reply box not found — may need to click "Reply" first' };
    }

    // Click to focus
    replyBox.click();
    await sleep(500);

    // Type with human-like delays
    await humanType(replyBox, text);
    await sleep(1000 + Math.random() * 1500);

    // Find and click the Reply/Post button
    const postBtn = document.querySelector('[data-testid="tweetButtonInline"]')
      || document.querySelector('[data-testid="tweetButton"]');

    if (!postBtn) {
      return { success: false, error: 'Post button not found' };
    }

    postBtn.click();
    await sleep(3000);

    return { success: true };
  }

  // ── Like a post ──────────────────────────────────────────────────────────

  async function likePost() {
    await sleep(2000);

    const likeBtn = document.querySelector('[data-testid="like"]');
    if (!likeBtn) {
      // Already liked?
      const unlikeBtn = document.querySelector('[data-testid="unlike"]');
      if (unlikeBtn) return { success: true, alreadyLiked: true };
      return { success: false, error: 'Like button not found' };
    }

    likeBtn.click();
    await sleep(2000);

    // Verify
    const verified = !!document.querySelector('[data-testid="unlike"]');
    return { success: verified, verified };
  }

  // ── Helpers ──────────────────────────────────────────────────────────────

  function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
  }

  async function humanType(element, text) {
    element.focus();
    for (const char of text) {
      // Use execCommand for contenteditable elements
      document.execCommand('insertText', false, char);
      await sleep(50 + Math.random() * 80);
      // Occasional pause after punctuation
      if ('.!?,;'.includes(char)) await sleep(200 + Math.random() * 300);
    }
  }
})();
