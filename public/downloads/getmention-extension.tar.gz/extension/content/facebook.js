/**
 * GetMention — Facebook Content Script
 */

(() => {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type !== 'EXECUTE_TASK' || msg.platform !== 'facebook') return;
    handleTask(msg).then(sendResponse).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  });

  async function handleTask({ action, text }) {
    switch (action) {
      case 'comment': return postComment(text);
      case 'like': return likePost();
      default: return { success: false, error: `Unknown action: ${action}` };
    }
  }

  async function postComment(text) {
    await sleep(3000);

    // Find comment box
    const commentBox = document.querySelector('[contenteditable="true"][role="textbox"][aria-label*="comment" i]')
      || document.querySelector('[contenteditable="true"][role="textbox"]');

    if (!commentBox) {
      // Try clicking "Write a comment" placeholder first
      const placeholder = document.querySelector('[aria-label*="Write a comment" i]')
        || document.querySelector('[placeholder*="Write a comment" i]');
      if (placeholder) {
        placeholder.click();
        await sleep(1500);
      }
    }

    const editor = document.querySelector('[contenteditable="true"][role="textbox"]');
    if (!editor) {
      return { success: false, error: 'Comment box not found' };
    }

    editor.click();
    await sleep(800);
    await humanType(editor, text);
    await sleep(1500);

    // Press Enter to submit
    editor.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
    await sleep(3000);

    return { success: true };
  }

  async function likePost() {
    await sleep(2000);

    const likeBtn = document.querySelector('div[aria-label="Like"][role="button"]');
    if (!likeBtn) {
      const removeLike = document.querySelector('[aria-label="Remove Like"]');
      if (removeLike) return { success: true, alreadyLiked: true };
      return { success: false, error: 'Like button not found' };
    }

    likeBtn.click();
    await sleep(2000);

    const verified = !!document.querySelector('[aria-label="Remove Like"]');
    return { success: verified, verified };
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function humanType(element, text) {
    element.focus();
    for (const char of text) {
      document.execCommand('insertText', false, char);
      await sleep(50 + Math.random() * 80);
      if ('.!?,;'.includes(char)) await sleep(200 + Math.random() * 300);
    }
  }
})();
