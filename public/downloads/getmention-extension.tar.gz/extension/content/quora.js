/**
 * GetMention — Quora Content Script
 */

(() => {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type !== 'EXECUTE_TASK' || msg.platform !== 'quora') return;
    handleTask(msg).then(sendResponse).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  });

  async function handleTask({ action, text }) {
    switch (action) {
      case 'comment': return postAnswer(text);
      case 'upvote': return upvoteAnswer();
      case 'follow': return followQuestion();
      default: return { success: false, error: `Unknown action: ${action}` };
    }
  }

  async function postAnswer(text) {
    await sleep(3000);

    // Click "Answer" button
    const answerBtn = document.querySelector('button[aria-label="Answer"]')
      || Array.from(document.querySelectorAll('button')).find(b => b.textContent?.trim() === 'Answer');
    if (answerBtn) {
      answerBtn.click();
      await sleep(2000);
    }

    // Find editor
    const editor = document.querySelector('[contenteditable="true"].doc')
      || document.querySelector('[contenteditable="true"]');
    if (!editor) return { success: false, error: 'Answer editor not found' };

    editor.click();
    await sleep(800);
    await humanType(editor, text);
    await sleep(1500);

    // Click submit
    const submitBtn = Array.from(document.querySelectorAll('button'))
      .find(b => b.textContent?.trim() === 'Post' || b.textContent?.trim() === 'Submit');
    if (submitBtn) submitBtn.click();
    await sleep(5000);

    return { success: true };
  }

  async function upvoteAnswer() {
    await sleep(2000);
    const btn = document.querySelector('button[aria-label="Upvote"]');
    if (!btn) return { success: false, error: 'Upvote button not found' };
    const text = btn.textContent?.trim() || '';
    if (text.startsWith('Upvoted')) return { success: true, alreadyUpvoted: true };
    btn.click();
    await sleep(2000);
    const after = btn.textContent?.trim() || '';
    return { success: after.startsWith('Upvoted'), verified: after.startsWith('Upvoted') };
  }

  async function followQuestion() {
    await sleep(2000);
    const btn = Array.from(document.querySelectorAll('button'))
      .find(b => /^Follow/i.test(b.textContent?.trim() || '') && !/Following/i.test(b.textContent?.trim() || ''));
    if (!btn) {
      const following = Array.from(document.querySelectorAll('button'))
        .find(b => /^Following/i.test(b.textContent?.trim() || ''));
      if (following) return { success: true, alreadyFollowing: true };
      return { success: false, error: 'Follow button not found' };
    }
    btn.click();
    await sleep(2000);
    return { success: true };
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function humanType(element, text) {
    element.focus();
    for (const char of text) {
      document.execCommand('insertText', false, char);
      await sleep(50 + Math.random() * 80);
      if ('.!?,;'.includes(char)) await sleep(200 + Math.random() * 300);
    }
  }
})();
