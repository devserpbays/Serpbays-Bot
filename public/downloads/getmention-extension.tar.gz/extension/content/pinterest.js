/**
 * GetMention — Pinterest Content Script
 */

(() => {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type !== 'EXECUTE_TASK' || msg.platform !== 'pinterest') return;
    handleTask(msg).then(sendResponse).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  });

  async function handleTask({ action, text }) {
    switch (action) {
      case 'comment': return postComment(text);
      case 'like': return likePin();
      default: return { success: false, error: `Unknown action: ${action}` };
    }
  }

  async function postComment(text) {
    await sleep(3000);

    const commentBox = document.querySelector('textarea[placeholder*="comment" i]')
      || document.querySelector('[contenteditable="true"]');
    if (!commentBox) return { success: false, error: 'Comment box not found' };

    commentBox.click();
    await sleep(800);

    if (commentBox.tagName === 'TEXTAREA') {
      commentBox.value = text;
      commentBox.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      await humanType(commentBox, text);
    }

    await sleep(1500);

    // Submit
    const submitBtn = document.querySelector('button[aria-label="Submit"]')
      || Array.from(document.querySelectorAll('button')).find(b => b.textContent?.trim() === 'Done' || b.textContent?.trim() === 'Submit');
    if (submitBtn) submitBtn.click();
    await sleep(3000);

    return { success: true };
  }

  async function likePin() {
    await sleep(2000);

    const heartBtn = document.querySelector('button[aria-label*="react" i]')
      || document.querySelector('button[aria-label*="like" i]');
    if (!heartBtn) return { success: false, error: 'Like button not found' };
    if (heartBtn.getAttribute('aria-pressed') === 'true') return { success: true, alreadyLiked: true };

    heartBtn.click();
    await sleep(2000);
    const verified = heartBtn.getAttribute('aria-pressed') === 'true';
    return { success: verified, verified };
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function humanType(element, text) {
    element.focus();
    for (const char of text) {
      document.execCommand('insertText', false, char);
      await sleep(50 + Math.random() * 80);
      if ('.!?,;'.includes(char)) await sleep(200 + Math.random() * 300);
    }
  }
})();
