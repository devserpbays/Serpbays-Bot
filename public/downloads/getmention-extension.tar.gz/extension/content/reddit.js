/**
 * GetMention — Reddit Content Script
 */

(() => {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type !== 'EXECUTE_TASK' || msg.platform !== 'reddit') return;
    handleTask(msg).then(sendResponse).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  });

  async function handleTask({ action, text }) {
    switch (action) {
      case 'comment': return postComment(text);
      case 'upvote': return upvotePost();
      default: return { success: false, error: `Unknown action: ${action}` };
    }
  }

  async function postComment(text) {
    await sleep(3000);

    // Works on both old.reddit.com and new reddit
    const isOldReddit = window.location.hostname === 'old.reddit.com';

    if (isOldReddit) {
      const commentBox = document.querySelector('.usertext-edit textarea');
      if (!commentBox) return { success: false, error: 'Comment box not found' };
      commentBox.focus();
      commentBox.value = text;
      commentBox.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(1000);
      const saveBtn = document.querySelector('.save-button button, button[type="submit"]');
      if (saveBtn) saveBtn.click();
      await sleep(3000);
      return { success: true };
    }

    // New Reddit
    const commentBox = document.querySelector('[contenteditable="true"][data-lexical-editor]')
      || document.querySelector('div[role="textbox"]');
    if (!commentBox) return { success: false, error: 'Comment box not found' };

    commentBox.click();
    await sleep(800);
    await humanType(commentBox, text);
    await sleep(1500);

    const submitBtn = document.querySelector('button[slot="submit-button"]')
      || document.querySelector('button[type="submit"]');
    if (submitBtn) submitBtn.click();
    await sleep(3000);

    return { success: true };
  }

  async function upvotePost() {
    await sleep(2000);

    const isOldReddit = window.location.hostname === 'old.reddit.com';

    if (isOldReddit) {
      const upArrow = document.querySelector('.arrow.up:not(.upmod)');
      if (!upArrow) {
        if (document.querySelector('.arrow.upmod')) return { success: true, alreadyUpvoted: true };
        return { success: false, error: 'Upvote arrow not found' };
      }
      upArrow.click();
      await sleep(1500);
      const verified = !!document.querySelector('.arrow.upmod');
      return { success: verified, verified };
    }

    // New Reddit
    const upBtn = document.querySelector('button[aria-label*="upvote" i]:not([aria-label*="downvote"])');
    if (!upBtn) return { success: false, error: 'Upvote button not found' };
    if (upBtn.getAttribute('aria-pressed') === 'true') return { success: true, alreadyUpvoted: true };
    upBtn.click();
    await sleep(1500);
    return { success: upBtn.getAttribute('aria-pressed') === 'true' };
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function humanType(element, text) {
    element.focus();
    for (const char of text) {
      document.execCommand('insertText', false, char);
      await sleep(50 + Math.random() * 80);
      if ('.!?,;'.includes(char)) await sleep(200 + Math.random() * 300);
    }
  }
})();
