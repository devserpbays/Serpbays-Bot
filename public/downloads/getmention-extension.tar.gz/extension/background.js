/**
 * GetMention Extension — Background Service Worker
 *
 * Runs in the background. Polls the server for tasks,
 * dispatches them to content scripts on the right platform tabs,
 * and reports results back.
 */

importScripts('utils/api.js');

const POLL_INTERVAL_MS = 60_000; // Check for new tasks every 60s
const PLATFORMS = {
  twitter: ['https://x.com', 'https://twitter.com'],
  youtube: ['https://www.youtube.com'],
  facebook: ['https://www.facebook.com'],
  reddit: ['https://www.reddit.com', 'https://old.reddit.com'],
  quora: ['https://www.quora.com'],
  pinterest: ['https://www.pinterest.com', 'https://in.pinterest.com'],
};

let isProcessing = false;

// ── Polling alarm ────────────────────────────────────────────────────────────

chrome.alarms.create('pollTasks', { periodInMinutes: 1 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'pollTasks') {
    await processTasks();
  }
});

// Also run on install/startup
chrome.runtime.onInstalled.addListener(() => {
  console.log('[GetMention] Extension installed');
  processTasks();
});

chrome.runtime.onStartup.addListener(() => {
  processTasks();
});

// ── Task processing ──────────────────────────────────────────────────────────

async function processTasks() {
  if (isProcessing) return;
  isProcessing = true;

  try {
    const apiKey = await GetMentionAPI.getApiKey();
    if (!apiKey) {
      console.log('[GetMention] No API key configured — skipping');
      return;
    }

    const { tasks, settings } = await GetMentionAPI.fetchTasks();

    if (!tasks || tasks.length === 0) {
      console.log('[GetMention] No pending tasks');
      return;
    }

    console.log(`[GetMention] ${tasks.length} task(s) to process`);

    const { autoPost } = await chrome.storage.sync.get('autoPost');

    for (const task of tasks) {
      // If auto-post is disabled, queue for manual review
      if (!autoPost) {
        await queueForReview(task);
        continue;
      }

      try {
        const result = await executeTask(task);
        await GetMentionAPI.completeTask(task.id, result);

        // Show notification
        chrome.notifications.create(`task-${task.id}`, {
          type: 'basic',
          iconUrl: 'icons/icon48.png',
          title: result.success ? 'Comment Posted' : 'Action Failed',
          message: result.success
            ? `${task.platform}: ${task.text?.slice(0, 50)}...`
            : `${task.platform}: ${result.error?.slice(0, 50)}`,
        });
      } catch (err) {
        console.error(`[GetMention] Task ${task.id} failed:`, err.message);
        await GetMentionAPI.completeTask(task.id, { success: false, error: err.message });
      }

      // Human-like delay between tasks (30-90 seconds)
      await sleep(30_000 + Math.random() * 60_000);
    }
  } catch (err) {
    console.error('[GetMention] Poll error:', err.message);
  } finally {
    isProcessing = false;
  }
}

// ── Task execution ───────────────────────────────────────────────────────────

async function executeTask(task) {
  const { platform, action, url, text } = task;

  // Open the URL in a new tab
  const tab = await chrome.tabs.create({ url, active: false });

  // Wait for page to load
  await waitForTabLoad(tab.id);
  await sleep(3000 + Math.random() * 2000);

  // Send task to content script
  const result = await chrome.tabs.sendMessage(tab.id, {
    type: 'EXECUTE_TASK',
    action,   // 'comment', 'like', 'upvote', 'follow'
    text,     // comment text (for comment action)
    platform,
  });

  // Close the tab after a delay
  await sleep(2000 + Math.random() * 3000);
  chrome.tabs.remove(tab.id).catch(() => {});

  return result || { success: false, error: 'No response from content script' };
}

// ── Review queue (when auto-post is off) ─────────────────────────────────────

async function queueForReview(task) {
  const { reviewQueue = [] } = await chrome.storage.local.get('reviewQueue');
  reviewQueue.push(task);
  await chrome.storage.local.set({ reviewQueue });

  // Update badge
  chrome.action.setBadgeText({ text: String(reviewQueue.length) });
  chrome.action.setBadgeBackgroundColor({ color: '#1d9bf0' });
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function waitForTabLoad(tabId) {
  return new Promise((resolve) => {
    const listener = (id, changeInfo) => {
      if (id === tabId && changeInfo.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
    // Timeout after 30s
    setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, 30000);
  });
}

// ── Message handler from popup ──────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'FORCE_POLL') {
    processTasks().then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg.type === 'EXECUTE_REVIEW_TASK') {
    executeTask(msg.task)
      .then(result => GetMentionAPI.completeTask(msg.task.id, result))
      .then(() => sendResponse({ ok: true }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }
  if (msg.type === 'GET_STATUS') {
    getStatus().then(sendResponse);
    return true;
  }
});

async function getStatus() {
  const { apiKey } = await chrome.storage.sync.get('apiKey');
  const { autoPost } = await chrome.storage.sync.get('autoPost');
  const { reviewQueue = [] } = await chrome.storage.local.get('reviewQueue');
  return {
    connected: !!apiKey,
    autoPost: !!autoPost,
    pendingReview: reviewQueue.length,
  };
}
