/**
 * API client for communicating with GetMention server.
 * Handles authentication, task fetching, and result reporting.
 */

const DEFAULT_SERVER = 'https://getmention.com';

async function getServerUrl() {
  const { serverUrl } = await chrome.storage.sync.get('serverUrl');
  return serverUrl || DEFAULT_SERVER;
}

async function getApiKey() {
  const { apiKey } = await chrome.storage.sync.get('apiKey');
  return apiKey;
}

async function apiRequest(endpoint, options = {}) {
  const serverUrl = await getServerUrl();
  const apiKey = await getApiKey();

  if (!apiKey) {
    throw new Error('Not connected — enter your API key in the extension popup');
  }

  const res = await fetch(`${serverUrl}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'X-Extension-Key': apiKey,
      ...options.headers,
    },
  });

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`API error ${res.status}: ${text.slice(0, 100)}`);
  }

  return res.json();
}

/**
 * Fetch pending tasks for the extension to execute.
 * Returns tasks like: { id, platform, action, url, text, ... }
 */
async function fetchTasks() {
  return apiRequest('/api/extension/tasks');
}

/**
 * Report task completion back to the server.
 */
async function completeTask(taskId, result) {
  return apiRequest('/api/extension/tasks/complete', {
    method: 'POST',
    body: JSON.stringify({ taskId, ...result }),
  });
}

/**
 * Get extension settings from server.
 */
async function fetchSettings() {
  return apiRequest('/api/extension/settings');
}

/**
 * Report platform login status.
 */
async function reportStatus(platform, loggedIn) {
  return apiRequest('/api/extension/status', {
    method: 'POST',
    body: JSON.stringify({ platform, loggedIn }),
  });
}

// Export for use in other scripts
if (typeof globalThis !== 'undefined') {
  globalThis.GetMentionAPI = { fetchTasks, completeTask, fetchSettings, reportStatus, getServerUrl, getApiKey };
}
