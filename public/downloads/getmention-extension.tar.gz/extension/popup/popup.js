/**
 * GetMention — Popup Script
 * Manages connection, settings, and task review.
 */

document.addEventListener('DOMContentLoaded', async () => {
  const setupSection = document.getElementById('setupSection');
  const mainSection = document.getElementById('mainSection');
  const statusBadge = document.getElementById('statusBadge');

  // Check current state
  const { apiKey, serverUrl, autoPost } = await chrome.storage.sync.get(['apiKey', 'serverUrl', 'autoPost']);

  if (apiKey) {
    showMain(serverUrl);
  } else {
    showSetup();
  }

  // ── Setup ──────────────────────────────────────────────────────────────────

  function showSetup() {
    setupSection.classList.remove('hidden');
    mainSection.classList.add('hidden');
    statusBadge.textContent = 'Not Connected';
    statusBadge.style.background = '#ef4444';
  }

  document.getElementById('connectBtn').addEventListener('click', async () => {
    const server = document.getElementById('serverInput').value.trim().replace(/\/$/, '');
    const key = document.getElementById('apiKeyInput').value.trim();
    const msgEl = document.getElementById('connectMsg');

    if (!key) {
      msgEl.textContent = 'API key is required';
      msgEl.className = 'msg error';
      msgEl.classList.remove('hidden');
      return;
    }

    try {
      // Test connection
      const res = await fetch(`${server || 'https://getmention.com'}/api/extension/ping`, {
        headers: { 'X-Extension-Key': key },
      });

      if (!res.ok) throw new Error('Invalid API key or server');

      await chrome.storage.sync.set({
        apiKey: key,
        serverUrl: server || 'https://getmention.com',
      });

      msgEl.textContent = 'Connected!';
      msgEl.className = 'msg success';
      msgEl.classList.remove('hidden');

      setTimeout(() => showMain(server), 500);
    } catch (err) {
      msgEl.textContent = err.message;
      msgEl.className = 'msg error';
      msgEl.classList.remove('hidden');
    }
  });

  // ── Main ───────────────────────────────────────────────────────────────────

  async function showMain(serverUrl) {
    setupSection.classList.add('hidden');
    mainSection.classList.remove('hidden');
    statusBadge.textContent = 'Connected';
    statusBadge.style.background = '#22c55e';

    // Dashboard link
    document.getElementById('dashboardLink').href = serverUrl || 'https://getmention.com';
    document.getElementById('dashboardLink').addEventListener('click', (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: serverUrl || 'https://getmention.com' });
    });

    // Auto-post toggle
    const { autoPost: ap } = await chrome.storage.sync.get('autoPost');
    document.getElementById('autoPostToggle').checked = !!ap;
    document.getElementById('autoPostToggle').addEventListener('change', (e) => {
      chrome.storage.sync.set({ autoPost: e.target.checked });
    });

    // Notification toggle
    const { showNotifications: sn } = await chrome.storage.sync.get('showNotifications');
    document.getElementById('notifyToggle').checked = sn !== false;
    document.getElementById('notifyToggle').addEventListener('change', (e) => {
      chrome.storage.sync.set({ showNotifications: e.target.checked });
    });

    // Load review queue
    loadReviewQueue();

    // Load stats
    loadStats();
  }

  async function loadReviewQueue() {
    const { reviewQueue = [] } = await chrome.storage.local.get('reviewQueue');
    const taskList = document.getElementById('taskList');
    document.getElementById('pendingCount').textContent = reviewQueue.length;

    if (reviewQueue.length === 0) {
      taskList.innerHTML = '<p style="font-size: 12px; color: #71717a; text-align: center; padding: 16px 0;">No tasks pending</p>';
      return;
    }

    const platformColors = { twitter: '#1d9bf0', youtube: '#f00', facebook: '#1877f2', reddit: '#ff4500', quora: '#b92b27', pinterest: '#e60023' };

    taskList.innerHTML = reviewQueue.map((task, i) => `
      <div class="task-item">
        <div class="task-platform" style="color: ${platformColors[task.platform] || '#888'}">${task.platform}</div>
        <div class="task-text">${(task.text || '').slice(0, 100)}${(task.text || '').length > 100 ? '...' : ''}</div>
        <div class="task-actions">
          <button class="btn-primary" data-action="approve" data-index="${i}">Post</button>
          <button class="btn-secondary" data-action="skip" data-index="${i}">Skip</button>
        </div>
      </div>
    `).join('');

    // Handle approve/skip
    taskList.querySelectorAll('button').forEach(btn => {
      btn.addEventListener('click', async () => {
        const idx = parseInt(btn.dataset.index);
        const action = btn.dataset.action;
        const { reviewQueue: q = [] } = await chrome.storage.local.get('reviewQueue');
        const task = q[idx];

        if (action === 'approve' && task) {
          chrome.runtime.sendMessage({ type: 'EXECUTE_REVIEW_TASK', task });
        }

        q.splice(idx, 1);
        await chrome.storage.local.set({ reviewQueue: q });
        chrome.action.setBadgeText({ text: q.length > 0 ? String(q.length) : '' });
        loadReviewQueue();
      });
    });
  }

  async function loadStats() {
    try {
      const status = await chrome.runtime.sendMessage({ type: 'GET_STATUS' });
      document.getElementById('pendingCount').textContent = status.pendingReview || 0;
    } catch {}
  }

  // ── Refresh ────────────────────────────────────────────────────────────────

  document.getElementById('refreshBtn').addEventListener('click', async () => {
    const btn = document.getElementById('refreshBtn');
    btn.textContent = 'Checking...';
    btn.disabled = true;
    try {
      await chrome.runtime.sendMessage({ type: 'FORCE_POLL' });
      await loadReviewQueue();
      btn.textContent = 'Done!';
      setTimeout(() => { btn.textContent = 'Check for New Tasks'; btn.disabled = false; }, 1500);
    } catch {
      btn.textContent = 'Error — try again';
      setTimeout(() => { btn.textContent = 'Check for New Tasks'; btn.disabled = false; }, 2000);
    }
  });

  // ── Disconnect ─────────────────────────────────────────────────────────────

  document.getElementById('disconnectBtn').addEventListener('click', async () => {
    await chrome.storage.sync.remove(['apiKey', 'serverUrl', 'autoPost']);
    await chrome.storage.local.remove(['reviewQueue']);
    chrome.action.setBadgeText({ text: '' });
    showSetup();
  });
});
